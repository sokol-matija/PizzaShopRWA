// Initialize Unsplash API client
const unsplash = createApi({
    accessKey: 'DK2ALZwtz82bP0eqwmJPkPpnUw-gU7r4wsZ3tBlts0I'
});

// Cache for storing image URLs
const imageCache = new Map();

// Function to get a random image
async function getRandomImage(query) {
    const cacheKey = `random_${query}`;
    
    // Check cache first
    if (imageCache.has(cacheKey)) {
        return imageCache.get(cacheKey);
    }

    try {
        const result = await unsplash.photos.getRandom({
            query: query,
            orientation: 'landscape'
        });

        if (result.type === 'success') {
            const photo = result.response;
            const imageUrl = photo.urls.regular;
            
            // Cache the result
            imageCache.set(cacheKey, imageUrl);
            
            // Track download as per Unsplash guidelines
            await unsplash.photos.trackDownload({
                downloadLocation: photo.links.download_location
            });

            return imageUrl;
        }
    } catch (error) {
        console.error('Error fetching random image:', error);
    }
    
    return null;
}

// Function to get a specific image by ID
async function getImageById(photoId) {
    const cacheKey = `photo_${photoId}`;
    
    // Check cache first
    if (imageCache.has(cacheKey)) {
        return imageCache.get(cacheKey);
    }

    try {
        const result = await unsplash.photos.get({
            photoId: photoId
        });

        if (result.type === 'success') {
            const photo = result.response;
            const imageUrl = photo.urls.regular;
            
            // Cache the result
            imageCache.set(cacheKey, imageUrl);
            
            // Track download as per Unsplash guidelines
            await unsplash.photos.trackDownload({
                downloadLocation: photo.links.download_location
            });

            return imageUrl;
        }
    } catch (error) {
        console.error('Error fetching image:', error);
    }
    
    return null;
}

// Export functions for use in Blazor
window.unsplashService = {
    getRandomImage: getRandomImage,
    getImageById: getImageById
}; 